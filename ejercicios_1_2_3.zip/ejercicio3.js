const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

let numeros = [];

function pedirNumero(i) {
  if (i < 3) {
    rl.question(`Ingrese el número ${i + 1}: `, (num) => {
      numeros.push(parseFloat(num));
      pedirNumero(i + 1);
    });
  } else {
    numeros.sort((a, b) => b - a);
    console.log("Números ordenados de mayor a menor:", numeros.join(", "));
    rl.close();
  }
}

pedirNumero(0);
