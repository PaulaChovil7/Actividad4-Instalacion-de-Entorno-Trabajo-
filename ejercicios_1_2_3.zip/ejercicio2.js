const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

rl.question("Ingrese el primer número: ", (num1) => {
  rl.question("Ingrese el segundo número: ", (num2) => {
    num1 = parseFloat(num1);
    num2 = parseFloat(num2);

    if (num1 > num2) {
      console.log("El primer número es mayor.");
    } else if (num2 > num1) {
      console.log("El segundo número es mayor.");
    } else {
      console.log("Ambos números son iguales.");
    }
    rl.close();
  });
});
